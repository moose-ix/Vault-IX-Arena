import os
from datetime import datetime, timezone
from enum import Enum
from uuid import UUID, uuid4

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import (
    Boolean, DateTime, ForeignKey, Integer, String, Text, create_engine,
    select, UniqueConstraint
)
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://vault:vault_dev_password@localhost:5432/vault_ix")
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "change-me-before-use")
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class Team(Base):
    __tablename__ = "teams"
    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    slug: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    abbreviation: Mapped[str] = mapped_column(String(8), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Match(Base):
    __tablename__ = "matches"
    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    team_a_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("teams.id"), nullable=False)
    team_b_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("teams.id"), nullable=False)
    best_of: Mapped[int] = mapped_column(Integer, default=5, nullable=False)
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="scheduled", nullable=False)
    team_a_map_wins: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    team_b_map_wins: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    winner_team_id: Mapped[UUID | None] = mapped_column(PGUUID(as_uuid=True), nullable=True)
    reported_by_discord_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    confirmed_by_discord_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    approved_by: Mapped[str | None] = mapped_column(String(32), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class MatchReport(Base):
    __tablename__ = "match_reports"
    __table_args__ = (UniqueConstraint("match_id", "reporting_team_id", name="uq_report_match_team"),)
    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    match_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("matches.id", ondelete="CASCADE"), nullable=False)
    reporting_team_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("teams.id"), nullable=False)
    claimed_team_a_wins: Mapped[int] = mapped_column(Integer, nullable=False)
    claimed_team_b_wins: Mapped[int] = mapped_column(Integer, nullable=False)
    submitted_by_discord_id: Mapped[str] = mapped_column(String(32), nullable=False)
    evidence_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="submitted", nullable=False)
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class MapResult(Base):
    __tablename__ = "map_results"
    __table_args__ = (UniqueConstraint("match_id", "map_number", name="uq_match_map_number"),)
    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    match_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("matches.id", ondelete="CASCADE"), nullable=False)
    map_number: Mapped[int] = mapped_column(Integer, nullable=False)
    map_name: Mapped[str] = mapped_column(String(100), nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False)
    team_a_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    team_b_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    winner_team_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), ForeignKey("teams.id"), nullable=False)

class AuditLog(Base):
    __tablename__ = "match_audit_logs"
    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    match_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), nullable=False)
    actor: Mapped[str | None] = mapped_column(String(32), nullable=True)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class TeamIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    slug: str = Field(pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$", max_length=120)
    abbreviation: str = Field(min_length=2, max_length=8)

class MatchIn(BaseModel):
    team_a_id: UUID
    team_b_id: UUID
    scheduled_at: datetime | None = None
    best_of: int = 5

    @model_validator(mode="after")
    def valid_match(self):
        if self.team_a_id == self.team_b_id:
            raise ValueError("A team cannot play itself.")
        if self.best_of not in (3, 5, 7):
            raise ValueError("best_of must be 3, 5, or 7.")
        return self

class ReportIn(BaseModel):
    reporting_team_id: UUID
    captain_discord_id: str = Field(min_length=1, max_length=32)
    team_a_map_wins: int = Field(ge=0, le=3)
    team_b_map_wins: int = Field(ge=0, le=3)
    evidence_url: str | None = None

class ConfirmIn(BaseModel):
    opposing_captain_discord_id: str = Field(min_length=1, max_length=32)

app = FastAPI(title="Vault IX Arena API", version="0.1.0",
              description="Starter league backend. Secure identity verification is required before production.")
Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_match(db: Session, match_id: UUID) -> Match:
    obj = db.get(Match, match_id)
    if not obj:
        raise HTTPException(404, "Match not found.")
    return obj

@app.get("/health")
def health():
    return {"status": "ok", "service": "vault-ix-arena-api"}

@app.post("/teams", status_code=201)
def create_team(payload: TeamIn, db: Session = Depends(get_db)):
    if db.scalar(select(Team).where(Team.slug == payload.slug)):
        raise HTTPException(409, "Team slug already exists.")
    team = Team(**payload.model_dump())
    db.add(team)
    db.commit()
    db.refresh(team)
    return {"id": str(team.id), "name": team.name, "slug": team.slug, "abbreviation": team.abbreviation}

@app.get("/teams")
def list_teams(db: Session = Depends(get_db)):
    teams = db.scalars(select(Team).where(Team.active.is_(True)).order_by(Team.name)).all()
    return [{"id": str(t.id), "name": t.name, "slug": t.slug, "abbreviation": t.abbreviation} for t in teams]

@app.post("/matches", status_code=201)
def create_match(payload: MatchIn, db: Session = Depends(get_db)):
    for tid in (payload.team_a_id, payload.team_b_id):
        if not db.get(Team, tid):
            raise HTTPException(404, f"Team not found: {tid}")
    match = Match(**payload.model_dump(), status="scheduled")
    db.add(match)
    db.commit()
    db.refresh(match)
    return match_json(match)

@app.get("/matches")
def list_matches(status: str | None = None, db: Session = Depends(get_db)):
    query = select(Match).order_by(Match.scheduled_at, Match.created_at)
    if status:
        query = query.where(Match.status == status)
    return [match_json(m) for m in db.scalars(query).all()]

@app.get("/matches/{match_id}")
def read_match(match_id: UUID, db: Session = Depends(get_db)):
    match = get_match(db, match_id)
    reports = db.scalars(select(MatchReport).where(MatchReport.match_id == match_id)).all()
    maps = db.scalars(select(MapResult).where(MapResult.match_id == match_id).order_by(MapResult.map_number)).all()
    return {
        **match_json(match),
        "reports": [{"team_id": str(r.reporting_team_id), "claimed_score": [r.claimed_team_a_wins, r.claimed_team_b_wins], "status": r.status} for r in reports],
        "maps": [{"map_number": m.map_number, "map_name": m.map_name, "mode": m.mode, "team_a_score": m.team_a_score, "team_b_score": m.team_b_score, "winner_team_id": str(m.winner_team_id)} for m in maps]
    }

@app.post("/matches/{match_id}/reports", status_code=201)
def submit_report(match_id: UUID, payload: ReportIn, db: Session = Depends(get_db)):
    match = get_match(db, match_id)
    if match.status in ("approved", "cancelled", "forfeit"):
        raise HTTPException(409, "This match is closed to reports.")
    if payload.reporting_team_id not in (match.team_a_id, match.team_b_id):
        raise HTTPException(403, "Only a participating team may report this match.")
    max_wins = match.best_of // 2 + 1
    if max(payload.team_a_map_wins, payload.team_b_map_wins) != max_wins:
        raise HTTPException(422, f"A best-of-{match.best_of} result must have a winner with {max_wins} map wins.")
    if payload.team_a_map_wins == payload.team_b_map_wins:
        raise HTTPException(422, "A series cannot end in a tie.")
    existing = db.scalar(select(MatchReport).where(
        MatchReport.match_id == match_id,
        MatchReport.reporting_team_id == payload.reporting_team_id
    ))
    if existing:
        existing.claimed_team_a_wins = payload.team_a_map_wins
        existing.claimed_team_b_wins = payload.team_b_map_wins
        existing.submitted_by_discord_id = payload.captain_discord_id
        existing.evidence_url = payload.evidence_url
        existing.status = "submitted"
        report = existing
    else:
        report = MatchReport(
            match_id=match_id,
            reporting_team_id=payload.reporting_team_id,
            claimed_team_a_wins=payload.team_a_map_wins,
            claimed_team_b_wins=payload.team_b_map_wins,
            submitted_by_discord_id=payload.captain_discord_id,
            evidence_url=payload.evidence_url
        )
        db.add(report)
    match.status = "awaiting_confirmation"
    match.reported_by_discord_id = payload.captain_discord_id
    db.add(AuditLog(match_id=match_id, actor=payload.captain_discord_id, action="result_submitted"))
    db.commit()
    db.refresh(report)
    return {"report_id": str(report.id), "match_status": match.status, "message": "Report saved. Opposing captain must confirm; authenticate captain identity before production."}

@app.post("/matches/{match_id}/confirm")
def confirm_result(match_id: UUID, payload: ConfirmIn, db: Session = Depends(get_db)):
    match = get_match(db, match_id)
    reports = db.scalars(select(MatchReport).where(MatchReport.match_id == match_id)).all()
    if not reports:
        raise HTTPException(409, "No report has been submitted.")
    first = reports[0]
    if payload.opposing_captain_discord_id == first.submitted_by_discord_id:
        raise HTTPException(403, "Confirmation must come from the opposing captain.")
    # In production, verify that this Discord user is the captain of the opposing team.
    if len(reports) >= 2:
        other = next((r for r in reports if r.reporting_team_id != first.reporting_team_id), None)
        if other and (other.claimed_team_a_wins, other.claimed_team_b_wins) != (first.claimed_team_a_wins, first.claimed_team_b_wins):
            match.status = "disputed"
            first.status = "disputed"
            other.status = "disputed"
            db.add(AuditLog(match_id=match_id, actor=payload.opposing_captain_discord_id, action="result_disputed", reason="Captain reports disagree"))
            db.commit()
            raise HTTPException(409, "Reports disagree; match flagged for admin review.")
    match.confirmed_by_discord_id = payload.opposing_captain_discord_id
    match.status = "awaiting_confirmation"
    first.status = "confirmed"
    db.add(AuditLog(match_id=match_id, actor=payload.opposing_captain_discord_id, action="result_confirmed"))
    db.commit()
    return {"match_status": match.status, "message": "Confirmation recorded. Admin approval is still required in this scaffold."}

@app.post("/matches/{match_id}/approve")
def approve_result(match_id: UUID, x_admin_key: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not x_admin_key or x_admin_key != ADMIN_API_KEY:
        raise HTTPException(401, "Valid admin key required.")
    match = get_match(db, match_id)
    if match.status == "disputed":
        raise HTTPException(409, "Resolve the dispute before approving.")
    reports = db.scalars(select(MatchReport).where(MatchReport.match_id == match_id)).all()
    if not reports or not match.confirmed_by_discord_id:
        raise HTTPException(409, "A report and opposing captain confirmation are required.")
    report = reports[0]
    match.team_a_map_wins = report.claimed_team_a_wins
    match.team_b_map_wins = report.claimed_team_b_wins
    match.winner_team_id = match.team_a_id if report.claimed_team_a_wins > report.claimed_team_b_wins else match.team_b_id
    match.status = "approved"
    match.approved_by = "admin-key"
    db.add(AuditLog(match_id=match_id, actor="admin-key", action="result_approved"))
    db.commit()
    return {"match": match_json(match), "message": "Result approved. Add standings/stat recalculation as a production service."}

@app.get("/standings")
def standings():
    return {"status": "not_implemented", "message": "Standings query is next milestone; only approved matches should count."}

def match_json(m: Match):
    return {
        "id": str(m.id), "team_a_id": str(m.team_a_id), "team_b_id": str(m.team_b_id),
        "best_of": m.best_of, "scheduled_at": m.scheduled_at.isoformat() if m.scheduled_at else None,
        "status": m.status, "team_a_map_wins": m.team_a_map_wins,
        "team_b_map_wins": m.team_b_map_wins,
        "winner_team_id": str(m.winner_team_id) if m.winner_team_id else None
    }
