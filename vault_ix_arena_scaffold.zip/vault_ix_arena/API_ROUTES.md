# Proposed API routes

## Public
- `GET /health`
- `GET /seasons/{season_id}/standings`
- `GET /seasons/{season_id}/matches`
- `GET /teams/{team_id}`
- `GET /teams/{team_id}/stats`
- `GET /players/{player_id}/stats`
- `GET /leaderboards?season_id=&mode=&metric=`

## Authenticated captain/player
- `POST /matches/{match_id}/availability`
- `POST /matches/{match_id}/proposals`
- `POST /matches/{match_id}/reports`
- `POST /matches/{match_id}/confirmations`
- `POST /matches/{match_id}/disputes`
- `GET /me`

## Admin
- `POST /seasons`
- `PATCH /seasons/{season_id}`
- `POST /seasons/{season_id}/fixtures/generate`
- `POST /tournaments`
- `POST /tournaments/{tournament_id}/seed`
- `POST /matches/{match_id}/approve`
- `POST /matches/{match_id}/corrections`
- `POST /stats/imports`
- `POST /stats/imports/{import_id}/review`
- `GET /admin/queue`
- `GET /admin/audit-log`

## API conventions
- Use UUID identifiers.
- Use UTC timestamps in storage and ISO-8601 in JSON.
- Paginate list endpoints.
- Add idempotency keys for report submissions and imports.
- Return `409 Conflict` for invalid state transitions and `422` for invalid payloads.
- Enforce roles and roster membership in the backend.
- Add rate limits, request IDs, structured logs, and API versioning before public launch.
