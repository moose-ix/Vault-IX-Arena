# Discord command implementation plan

## Captain commands
- `/schedule [team]`: show scheduled matches.
- `/availability match time`: submit availability in UTC with displayed local conversion.
- `/propose-match match time`: propose a time to the opposing captain.
- `/report-match match score evidence`: submit a series result and scoreboard URL.
- `/confirm-match match`: confirm an opponent's report.
- `/dispute match reason`: raise a dispute with evidence.
- `/playerstats player [season] [mode]`: query verified stats.
- `/teamstats team [season]`: query team records.
- `/standings [season]`: show standings from approved results.
- `/leaderboard metric [mode] [season]`: rank eligible players.

## Admin commands
- `/season-create`, `/season-config`, `/generate-fixtures`
- `/team-register`, `/roster-manage`
- `/tournament-create`, `/seed-teams`, `/bracket`
- `/approve-result`, `/correct-result`, `/verify-stats`
- `/admin-report`, `/export-data`

## Implementation rules
1. Every interaction calls the backend service; do not put business rules only in Discord handlers.
2. Derive the Discord user ID from the signed interaction context, never from a free-text user argument.
3. Resolve team captain status from the database and season roster.
4. Defer long-running Discord interactions and respond with an ephemeral status message.
5. Use Discord role checks plus backend authorization. Discord roles alone are not sufficient.
6. Keep the bot token in a secret environment variable and never log it.
7. Schedule reminders through a durable job queue; do not rely on in-memory timers.
8. All official statistics must be recalculated from verified map-level records after an approved result.
