# Vault IX Arena — first backend scaffold

A starter FastAPI + PostgreSQL backend for a community Call of Duty league.
It includes a database schema, teams/matches endpoints, captain result reporting,
opponent confirmation, and a basic approval workflow. It is a scaffold, not a
production-ready deployment.

## Requirements
- Python 3.12+
- Docker Desktop (recommended) or a PostgreSQL 16 server
- A Discord application/bot token for the later Discord integration

## Run locally
```bash
cp .env.example .env
docker compose up --build
```
Then open http://localhost:8000/docs

## Important workflow
1. Create two teams with `POST /teams`.
2. Create a match with `POST /matches`.
3. Submit a result with `POST /matches/{match_id}/reports`.
4. The opposing captain confirms with `POST /matches/{match_id}/confirm`.
5. An admin approves with `POST /matches/{match_id}/approve` and header
   `X-Admin-Key: change-me-before-use`.

For this scaffold, the captain is identified by a supplied `captain_discord_id`.
Before production, replace this simple identity check with verified Discord OAuth/
interaction identity and role-based authorization. Never trust a user-provided
Discord ID as authentication.

## Database
`schema.sql` is the fuller PostgreSQL schema design. The runnable app creates a
minimal subset of tables through SQLAlchemy on startup. In production, use Alembic
migrations rather than automatic table creation.

## Game-data integration
No automatic Black Ops 7 private-league import is assumed. Use captain-submitted
scores/screenshots until a data source is tested, authorized, and verified.
